from .settings import *  # noqa


DEBUG = True
